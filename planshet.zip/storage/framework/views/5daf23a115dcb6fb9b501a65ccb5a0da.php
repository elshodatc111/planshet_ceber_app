<?php $__env->startSection('content'); ?>
    <link href="https://atko.tech/NiceAdmin/assets/vendor/simple-datatables/style.css" rel="stylesheet">
    <div class="container">
        <div class="justify-content-center">
            <div class="card">
                <div class="card-header">Barcha Postlar</div>
                <div class="card-body">
                    <?php if(session('status')): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>
                    <table class="table text-center datatable" srtle="font-size:12px;">
                        <thead class="text-center">
                            <tr>
                                <th class="text-center">#</th>
                                <th class="text-center">Post Name</th>
                                <th class="text-center">Hodim</th>
                                <th class="text-center">Create Post</th>
                                <th class="text-center">Update Post</th>
                                <th class="text-center"></th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__empty_1 = true; $__currentLoopData = $Planshet; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr class="text-center">
                                <td><?php echo e($loop->index+1); ?></td>
                                <td><a href="<?php echo e(route('home_show', $item['id'])); ?>"><?php echo e($item['name']); ?></a></td>
                                <td><?php echo e($item['user']); ?></td>
                                <td><?php echo e($item['created_at']); ?></td>
                                <td><?php echo e($item['updated_at']); ?></td>
                                <td>
                                    <form action="<?php echo e(route('home_del',$item['id'])); ?>" method="POST"><?php echo csrf_field(); ?> <?php echo method_field('delete'); ?><button class="p-0 btn btn-danger">delete</button></form>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr>
                                    <td colspan='6' class="text-center">Postlar mavjud emas</td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
    <script src="https://atko.tech/NiceAdmin/assets/vendor/simple-datatables/simple-datatables.js"></script>
    <script src="https://atko.tech/NiceAdmin/assets/vendor/tinymce/tinymce.min.js"></script>
    <script src="https://atko.tech/NiceAdmin/assets/js/main.js"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\planshet\resources\views/home.blade.php ENDPATH**/ ?>
<?php $__env->startSection('content'); ?>
    <link href="https://atko.tech/NiceAdmin/assets/vendor/simple-datatables/style.css" rel="stylesheet">
    <div class="container">
        <div class="justify-content-center">
            <div class="card">
                <div class="card-header">Yangi post</div>
                <div class="card-body">
                    <?php if(session('status')): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>
                    <form action="<?php echo e(route('home_create_post')); ?>" method="post">
                        <?php echo csrf_field(); ?> 
                        <label for="name">Post nomi</label>
                        <input type="text" name="name" required class="form-control">
                        <label for="json">Post uchun JSON</label>
                        <textarea name="json" class="form-control"></textarea>
                        <div class="w-100 text-center">
                            <button class="btn btn-primary w-50 mt-3">Postni saqlash</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
    <script src="https://atko.tech/NiceAdmin/assets/vendor/simple-datatables/simple-datatables.js"></script>
    <script src="https://atko.tech/NiceAdmin/assets/vendor/tinymce/tinymce.min.js"></script>
    <script src="https://atko.tech/NiceAdmin/assets/js/main.js"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\planshet\resources\views/home_create.blade.php ENDPATH**/ ?>
<?php $__env->startSection('content'); ?>
    <link href="https://atko.tech/NiceAdmin/assets/vendor/simple-datatables/style.css" rel="stylesheet">
    <div class="container">
        <div class="justify-content-center">
            <div class="card">
                <div class="card-header">Profel malumotlari</div>
                <div class="card-body">
                    <?php if(session('status')): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>
                    <?php if(session('error')): ?>
                        <div class="alert alert-danger" role="alert">
                            <?php echo e(session('error')); ?>

                        </div>
                    <?php endif; ?>
                    <label for="">FIO</label>
                    <input type="text" required disabled value="<?php echo e(auth()->user()->name); ?>" class="form-control">
                    <label for="">Email</label>
                    <input type="text" required disabled value="<?php echo e(auth()->user()->email); ?>" class="form-control">
                    <label for="">Lavozim</label>
                    <input type="text" required disabled value="<?php echo e(auth()->user()->type); ?>" class="form-control">
                </div>
            </div>
            <br>
            <div class="card">
                <div class="card-header">Parolni yangilash</div>
                <div class="card-body">
                    <form action="<?php echo e(route('update_password')); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <label for="current_password">Joriy parol:</label>
                        <input type="password" class="form-control" name="current_password" id="current_password" required>
                        
                        <label for="new_password">Yangi parol:</label>
                        <input type="password" class="form-control" name="new_password" id="new_password" required>
                        
                        <label for="new_password_confirmation">Yangi parolni tasdiqlang:</label>
                        <input type="password" class="form-control" name="new_password_confirmation" id="new_password_confirmation" required>
                        
                        <div class="w-100 text-center mt-3">
                        <button type="submit" class="btn btn-primary w-50">Parolni Yangilash</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
    <script src="https://atko.tech/NiceAdmin/assets/vendor/simple-datatables/simple-datatables.js"></script>
    <script src="https://atko.tech/NiceAdmin/assets/vendor/tinymce/tinymce.min.js"></script>
    <script src="https://atko.tech/NiceAdmin/assets/js/main.js"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\planshet\resources\views/profel.blade.php ENDPATH**/ ?>